DevColorz 1.0.0
===============

A colour-system studio you can host yourself.
https://github.com/ZcarecroW/devcolorz


INSTALLING
----------

1. Upload the CONTENTS of this folder (not the folder itself) into the
   document root of a domain or subdomain. That is usually the directory
   your host calls public_html, httpdocs or www.

   index.html must end up directly in the document root. If you open your
   site and see a directory listing or a 404, the files are one level
   too deep.

   A subfolder works too, for example example.com/colors/ -- the app uses
   hash-based routing so it does not care where it lives.

2. Open your site in a browser. The setup wizard takes over from there.

   It checks your server first and tells you plainly if anything is
   missing. Then it asks for a setup code, which it has written to
   storage/setup-code.txt -- open that file over FTP or in your host's
   file manager and paste what is inside.

   That step is not busywork. It proves you are the person who uploaded
   these files, rather than whoever happened to find the URL first.

3. Copy the cron token and invitation code the wizard shows you. They are
   displayed once and cannot be retrieved afterwards, only replaced.

4. Add a cron job, every five minutes:

      curl -fsS -H "X-Cron-Key: YOUR-TOKEN" https://example.com/cron.php

   Without it the app still works; you just lose outgoing email and old
   rows are never pruned.


REQUIREMENTS
------------

  PHP         8.2 or newer, with pdo_sqlite
  SQLite      3.24 or newer (3.37+ preferred)
  Web server  Apache with .htaccess, or nginx -- see the install guide
  HTTPS       strongly recommended
  Email       optional, but account confirmation needs mail()

No Composer, no Node, no database server, no build step.


UPGRADING
---------

Upload a newer release over the top, but do NOT overwrite:

  config.php    your installation's secrets
  storage/      your database, sessions and backups

Schema migrations run automatically on the first request afterwards.


FULL DOCUMENTATION
------------------

  Install guide   https://github.com/ZcarecroW/devcolorz/blob/main/docs/INSTALL.md
  User guide      https://github.com/ZcarecroW/devcolorz/blob/main/docs/GUIDE.md


LICENCE
-------

MIT -- free for any use, including commercial. See LICENSE.
Third-party components are credited in THIRD-PARTY.md in the repository.
